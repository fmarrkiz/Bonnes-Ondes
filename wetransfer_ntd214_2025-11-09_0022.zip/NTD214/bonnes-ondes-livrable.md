
# Bonnes Ondes - NTD214
## Features

### Élements du site

* Produits classés par type 
  * Instruments
    * Instruments à vent
    * Instruments à cordes
    * Percussions
    * Instruments à touche
    * Accessoires (ampli, loop, ...)
    * Le paradis des ingénieurs du son
  * Partitions
  * Métronomes
  * Accordeurs




### Structure du site

* Titre principal

Bonnes Ondes

* Sous-titre

Trouvez l'instrument qui vous fera vibrer ! Parfait pour une jam

* Une barre de navigation

Coup de coeur | Percussions | Cordes | Vents | Partitions | Accessoires 

1. Coup de coeur
  * Kora
2. Percussions
  * Batteries
  * Percussions traditionnelles
  * Pans
3. Cordes
  * Guitares
  * Basses
  * Pianos
  * Autres instruments à ordes pincées
  * Autres instruments à cordes frottées
4. Vents
  * Flûtes
  * Trompettes
  * Saxophones
  * Autres intrusments à vent
5. Partitions
6. Accessoires
  * Métronomes
  * Accordeurs
  * Ampli
  * Loop



* 5 images libres de droits



